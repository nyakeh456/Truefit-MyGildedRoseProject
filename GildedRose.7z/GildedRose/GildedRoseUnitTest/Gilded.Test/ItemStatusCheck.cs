﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose.Gilded.Test
{
    public class ItemStatusCheck : SimpleItemCheck
    {
    }
}
