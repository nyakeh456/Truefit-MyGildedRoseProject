﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose.Gilded.Test
{
    public static  class TestItems
    {
        public static Item ConjuredItem
        {
            get
            {
                return new Item
                {
                    Name = "Conjured Mana Cake",
                    SellIn = 20,
                    Quality = 1
                };
            }
        }
        public static Item BackStageItem
        {
            get
            {
                return new Item
                {
                    Name = "Backstage passes to a TAFKAL80ETC concert",
                    SellIn = 20,
                    Quality = 1
                };
            }
        }
        public static Item CheckAgeBrie
        {
            get
            {
                return new Item
                {
                    Name = "Aged Brie",
                    SellIn = 20,
                    Quality = 1
                };
            }
        }
    }
}
