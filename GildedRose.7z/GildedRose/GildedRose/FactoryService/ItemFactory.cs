﻿using GildedRose.Gilded.Service;
using System;
using System.Collections.Generic;
using System.Text;
namespace GildedRose
{
    public  class ItemFactory
    {
        private static bool IsSulfuras(Item item)
        {
            return item.Name.Equals("Sulfuras, Hand of Ragnaros");
        }
        private static  bool IsAgedBrie(Item item)
        {
            return item.Name.Equals("Aged Brie");
        }
        private static bool Backstage(Item item)
        {
            return item.Name.Equals("Backstage passes to a TAFKAL80ETC concert");
        }
        private static bool Conjured(Item item)
        {
            return item.Name.Equals("Conjured Mana Cake");
        }
         public static RetailItem  getItem(Item item)
        {
            if (IsSulfuras(item))
            {
                return new Sulfuras_Item(item);
            }
            else if (Backstage(item))
            {
                return new BackStage_Item(item);
            }else if (Conjured(item))
            {
                return new Conjured_Item(item);
            }else if (IsAgedBrie(item))
            {
                return new AgedBrie_Item(item);
            }
            return new NormalUpdates(item);
        }     
    }
}
