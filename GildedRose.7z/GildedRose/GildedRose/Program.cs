﻿using System;
using System.Collections.Generic;
namespace GildedRose
{
    class Program
    {    
          List<Item> Items = null;
     public   static void Main(string[] args)
        {          
            var app = new Program()
            {
                //Test data
                Items = new List<Item>
                      {
                         new Item {Name = "+5 Dexterity Vest", SellIn = 10, Quality = 20},
                         new Item {Name = "Aged Brie", SellIn = 2, Quality = 0},
                         new Item {Name = "Elixir of the Mongoose", SellIn = 5, Quality = 7},
                         new Item {Name = "Sulfuras, Hand of Ragnaros", SellIn = 0, Quality = 80},
                         new Item{ Name = "Backstage passes to a TAFKAL80ETC concert",SellIn = 15, Quality = 20 },
                         new Item {Name = "Conjured Mana Cake", SellIn = 3, Quality = 6}
                                                      }

            };
            ItemFactory ItemFactory = new ItemFactory();
            foreach(var item in app.Items)
            {
               var _items =  ItemFactory.getItem(item);

                //Console.WriteLine("{0} {1} {2}", item.Name,item.Quality, _items.SellIn);
            }
            Console.ReadKey();
        }
        } 
}

