﻿using System;
using System.Collections.Generic;
using System.Text;
namespace GildedRose.Gilded.IService
{
    public interface IRetailItem
    {
        void IncreaseQuality();
         void DecreaseQuality();
        bool HasItemExpired();
        //void UpdataItem();
        //void NormalUpdate(Item item);
    }
}
