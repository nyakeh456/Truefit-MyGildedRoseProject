﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose.Gilded.Test
{
    public class SimpleItemCheck
    {
        //Set constant value for Max_quality 
        protected static readonly int Max_Quality = 50;

        protected Item _item;

        public List<Item> Items { get; private set; }

        protected void SetupItemcheck(Item item)
        {
            _item = item;
            Program app = new Program()
            {
               
            };
            Items = new List<Item> { _item, };
        }
    }
}
