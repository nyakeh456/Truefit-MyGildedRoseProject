﻿using System.Collections.Generic;

namespace GildedRose
{
    public  class ItemStatusCheck
    {
        //Constant Max  value for all items, 
        protected static readonly int MAX_QUALITY_VALUE = 50;
        protected Item _item;

        protected void ItemSetUp(Item item)
        {
            _item = item;
            Program app = new Program()
            {
                //Items = new List<Item>
                //{
                //    _item,
                //}
            };
            
          
        }
    }
}
