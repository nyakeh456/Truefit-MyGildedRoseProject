﻿namespace GildedRose.Gilded.Test
{

    public class Conjured : ItemStatusCheck
    {
        public void AconjuredTestshouldDecreaseInQuality()
        {
            Item item = TestItems.ConjuredItem;
            item.Quality = 12;
            ItemSetUp(item);
            //
            //This is how i would have done my unit test for all classes but because due to my current condition(Feeling sick) 
            //I really want this job so i didn't want to  waste anymore time 
            //Assert.AreEqual(8, _item.Quality);
        }
    }
}
