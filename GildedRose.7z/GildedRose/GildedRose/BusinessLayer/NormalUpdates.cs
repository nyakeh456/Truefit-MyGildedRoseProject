﻿using GildedRose.Gilded.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose
{
    public   class NormalUpdates : RetailItem
    {
        public NormalUpdates(Item item) : base(item)
        {
            item.SellIn--;
            if (item.Quality <= 0)
            {
                return;
            }
            else if (item.Quality == 1)
            {
                item.Quality = 0;
            }
            else
            {
                item.Quality -= item.SellIn < 0 ? 2 : 1;
            }
        }
    }
}
