﻿using GildedRose.Gilded.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose
{
    public class AgedBrie_Item : RetailItem
    {
       public AgedBrie_Item(Item item ): base(item) 
        {
            IncreaseQuality();
            if(HasItemExpired())
            {
                IncreaseQuality();
            }
        }
    }    
}
