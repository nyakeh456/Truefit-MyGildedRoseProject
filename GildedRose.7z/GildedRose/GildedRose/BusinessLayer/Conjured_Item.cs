﻿
using GildedRose.Gilded.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose
{
    public class Conjured_Item : RetailItem
    {
        public Conjured_Item(Item item) : base(item) {
            this.UpdataItem();
        }
       public override void UpdataItem()
        {
            if (IsQuality)
            {
                DecreaseQuality();
            }

            SellIn--;

            if (SellIn < 0 && IsQuality)
            {
                DecreaseQuality();
            }
        }
       }
    }
    
 


