﻿using GildedRose.Gilded.Service;
using System;
using System.Collections.Generic;
using System.Text;
namespace GildedRose
{
     public class BackStage_Item : RetailItem
    {
        public BackStage_Item(Item item):base(item)
        {
            this.UpdateQuality();
        }
        protected override void UpdateQuality()
        {
            IncreaseQuality();
            if(SellIn < 11)
            {
                IncreaseQuality();
            }
            if(SellIn < 6)
            {
                IncreaseQuality();
            }
            if(SellIn < 0)
            {
                Quality = 0;
            }
        }
    }
}
