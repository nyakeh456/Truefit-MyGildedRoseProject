﻿using GildedRose.Gilded.Service;
using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose
{
    public class Sulfuras_Item : RetailItem
    {
        public Sulfuras_Item(Item item) : base(item) { }
        protected override void UpdateQuality(){
        }
        protected override void UpdateSellIn() { }
    }   
    }

