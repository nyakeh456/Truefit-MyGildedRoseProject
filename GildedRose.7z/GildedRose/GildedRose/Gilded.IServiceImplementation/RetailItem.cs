﻿using GildedRose.Gilded.IService;
using System;
using System.Collections.Generic;
using System.Text;

namespace GildedRose.Gilded.Service
{
    //private readonly Lazy<IRetailItem> retailRepository;

    public class RetailItem : IRetailItem
    {
        private Item _item;
        public RetailItem(Item item)
        {
            this._item = item;
        }
        public int Quality
        {
            get { return _item.Quality; }
            set { _item.Quality = value; }
        }
        public int SellIn
        {
            get { return _item.SellIn; }
            set { _item.SellIn = value; }
        }
        private void UpdateCommonItem(Item item)
        {
            DecreaseQuality();
            if(item.SellIn < 0)
            {
                DecreaseQuality();
            }
        }
        public void DecreaseQuality()
        {
            if(_item.Quality > 0)
            {
                _item.Quality--;
            }
        }
        public bool HasItemExpired()
        {
            return _item.SellIn < 0;
        }
        public void IncreaseQuality()
        {
           if(_item.Quality < 50)
            {
                _item.Quality++;
            }
        }
        protected virtual void UpdateQuality() {
            DecreaseQuality();
            if(HasItemExpired())
            {
                DecreaseQuality();
            }
        }
        protected virtual void UpdateSellIn(){
            SellIn--;
        }
        public virtual void UpdataItem(){
            UpdateQuality();
            UpdateSellIn();
        }
        public bool IsQuality
        {
            get
            {
                return Quality > 0;
            }
        }

        public void ResetQuality()
        {
            Quality = (Quality - Quality);
        }

    }
}
