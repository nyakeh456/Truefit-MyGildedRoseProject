﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GildedRose.UnitTest
{
    [TestClass]
    public class ConjuredQualityShouldDecrease : Conjured_Item
    {

    }
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
